# Shared backend query performance

Baseline collection is in progress. No before/after speedup is claimed yet.
The maintained harness measures real PostgreSQL and the actual compiled service,
HTTP controller, PAT guard, and MCP runtime. Database repositories are not mocked.
The separate correctness probes intentionally expose bugs in the original code.

## Reproduction

Use Node 24 or later, Yarn, and a disposable local PostgreSQL database named
`splice_backend_benchmark`. Supply `BACKEND_BENCHMARK_DATABASE_URL` in the invoking
process environment. The runner refuses another database name, a non-loopback
host, or a non-PostgreSQL URL. It creates and drops only a uniquely named schema;
it never synchronizes or truncates an application's schema.

The original source is retained in
[the source archive](performance/backend-query/baseline-backend-source.tar.gz),
with [the complete input manifest](performance/backend-query/baseline-source-manifest.json).
The archive contains backend source, tests, scripts, lockfile and build configuration;
it excludes environment credentials, node_modules, build output, and screenshots.
Its source includes the earlier dashboard/SSR work present at baseline capture,
not merely Git HEAD. Extract it into a temporary directory and install its locked
dependencies (or use the existing matching node_modules).

Compile the selected backend independently of the harness:

```bash
yarn tsc -p tsconfig.build.json --outDir .benchmark-build --incremental false
```

Run the common harness from the working backend directory, pointing
`BENCHMARK_SOURCE_ROOT` at the selected backend directory, not its build output:

```bash
yarn ts-node -r tsconfig-paths/register scripts/benchmark-backend.ts capture --variant before --rows 10000 --samples 100 --warmups 5 --run 1 --full
yarn ts-node -r tsconfig-paths/register scripts/benchmark-backend.ts capture --variant after --rows 10000 --samples 100 --warmups 5 --run 1 --full
yarn ts-node -r tsconfig-paths/register scripts/benchmark-backend.ts compare
```

Repeat each capture in three independent processes (`--run 1`, `2`, `3`) for
`--rows 10000`, `100000`, and `1000000`. Each fixture gives the target user one
tenth of the main transaction rows and another owner the remaining rows.
`--filter` selects a scenario-name substring. `--no-transports` selects service
work only. `--output` isolates a supplemental suite's reports from the main
comparison matrix. Never compare exploratory one-sample reports as p95 evidence.
The maintained matrix runner automates those independent processes:

```bash
yarn ts-node -r tsconfig-paths/register scripts/benchmark-backend.ts matrix --variant before --suite main --resume
yarn ts-node -r tsconfig-paths/register scripts/benchmark-backend.ts matrix --variant before --suite extended --resume
yarn ts-node -r tsconfig-paths/register scripts/benchmark-backend.ts matrix --variant before --suite shape --resume
yarn ts-node -r tsconfig-paths/register scripts/benchmark-backend.ts matrix --variant before --suite sync --resume
yarn ts-node -r tsconfig-paths/register scripts/benchmark-backend.ts matrix --variant before --suite mixed --resume
yarn ts-node -r tsconfig-paths/register scripts/benchmark-backend.ts matrix --variant before --suite memory --resume
```

Repeat with `--variant after` and the final compiled source. Run matrices
sequentially on this shared machine. The mixed suite runs each PAT HTTP/Auth0 MCP
concurrency 1/5/10 phase for 30 seconds, with and without a concurrent 50-row sync.
The memory suite launches a fresh process for each daily/compact 20/100-account
ten-year history scenario, with 5 warmups and 100 calls. A separate sampling thread
measures process RSS every 5 ms while the application thread is busy. It excludes
seeding and includes that scenario's preflight/warmups/calls; worker overhead is
included identically in both variants. The maximum is a sampled peak, not an
estimate of peak heap or proof of an unobserved instantaneous RSS maximum.
Memory-only processes expose GC and collect once before the scenario; normal
latency captures do not force GC. Create `.pause-captures` in the output root to
pause the matrix before its next capture, then remove it after other validation
finishes. Wait for the pause announcement before starting competing load; current
captures finish normally. The pause marker is temporary and must not be committed.

The final `compare` command checks all required suites. Use `compare --suite main`
for an early main-only report; `--output` points at an individual supplemental
directory. Migration runtime and blocked-read measurements can be reproduced with
[the migration runner](../test/migrations/measure-query-migrations.cjs), using
the same guarded database environment.

Additional suites use the same guarded lifecycle:

```bash
yarn ts-node -r tsconfig-paths/register scripts/benchmark-backend.ts capture --variant before --samples 1 --warmups 0 --correctness --filter transactions.date-filter --no-transports --output docs/performance/backend-query/probes
yarn ts-node -r tsconfig-paths/register scripts/benchmark-backend.ts capture --variant before --samples 100 --warmups 5 --sync --filter sync. --no-transports --output docs/performance/backend-query/sync
yarn test --config test/jest-performance-postgres.json --runInBand
```

The PostgreSQL Jest case is opt-in through the same URL and requires a compiled
source root. The guard/statistics tests run without a database. New migrations
are applied with the actual TypeORM migration runner, not schema synchronization.

## What each number measures

Each normal scenario makes one preflight validation call, five unmeasured warmups,
then at least 100 measured calls. Raw samples preserve wall time, process CPU,
heap change/RSS at call completion, SELECT count, SQL elapsed time, SQL result row
count and serialized row bytes, response bytes, and gzip bytes. Write/transaction
statement counts are recorded separately for sync/PAT cases. SQL byte counting
and gzip happen after the measured service interval. Application code is emitted
with the production TypeScript build settings; it is not interpreted by ts-node.
The observer records only measured intervals and releases records between calls.
Post-interval SQL byte serialization can still influence garbage collection in a
later call; matched variants retain this instrumentation, and repeated-run spread
is reported. Serialization has its own timing, and connection acquisition wait is
recorded at the PostgreSQL driver's pool boundary. Mixed phases also record
event-loop delay, throughput, errors and pool-wait distributions. Provider network
time and model latency are deliberately absent, rather than estimated.

The first observer retained SQL rows during unmeasured warmups. At 1m fixture rows,
that observer exhausted Node's 4 GiB heap during legacy search. This was a harness
failure, **not evidence of an application OOM**. Those six completed runs and the
partial run are preserved under `superseded-observer-v1/`; all primary comparisons
use a complete rerun with the corrected v2 observer. V2 also counts SQL bytes one
row at a time, avoiding a giant intermediate JSON string.

Service intervals include result JSON serialization. HTTP intervals include
loopback HTTP, the real PAT guard/controller and database services. MCP intervals
include loopback Streamable HTTP, a locally signed JWT validated by the real
Auth0 MCP gate, database-backed identity lookup, tool schemas and result formatting.
The local JWT authority supplies JWKS without contacting Auth0. Initialization
and handshake are recorded separately from repeated tool calls. No model
inference, internet latency, or provider network time is included.

The clock is fixed at `2026-09-05T12:00:00Z`. The pool maximum is 10. Schedules,
external providers, log shipping and notification listeners are absent/disabled;
provider/auth dependencies outside the tested paths throw if called. The provider
sync suite supplies deterministic responses and measures only database application,
with fixture cleanup and generation acquisition outside that interval.

The data is database-warm after seeding and `ANALYZE`; this is **not** a cold
PostgreSQL-cache benchmark. Process-cold startup is not included in repeated-call
latency. Per-call RSS is descriptive, not an isolated peak-memory comparison.
Use a separate process and `--filter` for an isolated workload memory run. The
machine also hosts developer activity; compare spread across independent runs and
investigate unstable tails before making an improvement claim.

Representative SELECTs retain `EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)`, SQL,
synthetic parameters, and observed rows/bytes. The real migration list, index
and column definitions, source file hashes, fixture identity, Node/PostgreSQL
versions, CPU and pool settings accompany every capture. Unique schema names
are replaced in printed query text; captured plans contain test-owned schema names.

## Baseline correctness evidence

[The PostgreSQL reproduction](performance/backend-query/probes/before-10000-run1.json)
recorded:

| Scenario                              | Original result                        | Required corrected result      |
| ------------------------------------- | -------------------------------------- | ------------------------------ |
| Exactly full final transaction page   | 100 rows, `hasMore: true`              | `hasMore: false`               |
| Missing FX                            | Explicit failure                       | Preserve explicit failure      |
| Exact ETH ingestion                   | Final wei lost                         | Preserve `1000000000000000001` |
| 10 ETH persistence                    | PostgreSQL integer overflow            | Exact storage succeeds         |
| Cleared manual portfolio              | Web 0 positions; MCP 100 old positions | Both return 0                  |
| Failure on second holding write       | First position remains                 | No partial positions remain    |
| Reversed provider response completion | Older response overwrites newer        | Reject stale generation        |
| Concurrent settings patches           | 19 of 20 trials lost an edit           | No unrelated edit lost         |
| Two EUR-cent rows at 1.5 USD rate     | Summary 3 cents; drilldown 4           | Both 4 cents                   |

The real query runner additionally discovered that the original HTTP amount sort
fails inside TypeORM's joined pagination metadata handling. A 5,000-row banking
sync exceeds the PostgreSQL bind-parameter budget. Those are recorded as known
baseline failures, not timed successes; fixing them is a correctness improvement.
Unexpected failures abort capture instead of silently omitting a scenario.

The sparse EUR history fixture exposes another exact-arithmetic correction:
100 accounts total 10,505,000 EUR cents and the fixed 1.1 quote implies exactly
115,555 USD. The original daily chart reports `115554.99999999999`; the new chart
reports the exact string `"115555"`. Its integer net-worth total already reconciled.
The comparator accepts only this named input/output correction, while checking
all dates, labels, account summaries and integer totals unchanged. This profile is
separate from the entirely equivalent USD history lane.

## Coverage and completion

The main matrix currently covers every existing transaction sort, first/deep
pages, date filters, legacy search, FX pages on 1/10/100 dates and 1/3 currencies,
latest holdings for 1/20/100 accounts with 100 positions each, month/year/ten-year
history with 20/100 accounts, summary/audit cash flow, isolated equal-amount
matching CPU, PAT HTTP, MCP history/transactions/holdings and the cash-flow App
comparison pipeline. A supplemental sync matrix covers 50/500/5,000 banking rows
with rules off/on, modified banking rows, and investment activities at the same
sizes. Extended shapes cover empty/10-position holdings, portfolio conversion,
compact history, and rare/no-match converted searches over 100k candidate rows.
The last pair validates every continuation against a separately ordered SQL oracle,
outside the measured interval. Shape profiles add rules/lookaround cash-flow
reports and dense/prior-FX history. Correctness integration suites separately
exercise failure, retries, sync fencing, pending replacements and settings races.
Deep cursor profiles acquire the preceding cursor outside the measured interval,
then compare the new count-free continuation with the original deep offset page.
They require the same ordered data, and the captured continuation SQL must contain
neither OFFSET nor a count. Portfolio profiles include 0/10/100 positions and
mixed currencies/snapshot dates.

Final matrix execution and final-source comparison remain in progress. The
current scripts and exploratory captures do not substitute for all required
100-call, three-process runs. Migration runtime and blocked-read measurements are
recorded separately in `backend/docs/performance/migrations/`.

Comparisons must keep exact-money type changes and intentional date/rounding
corrections separate from equivalent-result speedups. Money numbers are normalized
to strings for comparison, never rounded back through a JavaScript number.
Transaction order and exact values must match. Holdings are compared by unique
identity because the new batched reader changes unspecified position ordering;
its complete snapshot metadata is checked separately. New cursor, sampling, and
actual FX observation metadata are checked explicitly rather than suppressing
financial fields. Daily series must match every point. Compact series must keep
original point values, requested endpoints, complete account summaries and exact
totals, obey the point budget, and reduce chart JSON by at least 80%.

The comparator fails on missing/mismatched inputs, unexpected economic differences,
incomplete sampling, and deterministic query/shape budgets. `comparison.json`
retains each run and spread; `comparison.md` presents the median of per-process
percentiles. Regressions exceeding both 10% and 5 ms are flagged for explanation.
`--exploratory` permits smaller samples for diagnosis only. The final before/after
table will be appended after implementation and validation.

## Shared entry points for future work

| Need                                         | Entry point                                                                       | Contract and ownership                                                                                                                                                                                     |
| -------------------------------------------- | --------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Transaction pages, search, report candidates | `TransactionQueryService.readPage`, `search`, `readAnalysis`, `readMcpCandidates` | Always pass authenticated `userId`. The service owns SQL, filters and projections; detail/sync-only provider payloads stay out of list/report reads.                                                       |
| Infinite scrolling                           | `TransactionService.findPage`                                                     | Initial request may obtain the exact total; continuation sends the opaque sort/filter-bound cursor and omits the count. `findAllPaginated` is the offset adapter for remaining callers.                    |
| Historical conversion                        | `CurrencyConversionService.getResolvedRates`                                      | Batch unique currency-pair/date requests. Exact quotes include requested and actual observation dates/source. Use effective transaction date for spending; preserve valuation dates for balances/holdings. |
| Latest/date-specific holdings                | `HoldingsQueryService.read`                                                       | One coherent read snapshot for owned accounts, completed headers and positions. An empty completed header is a fact; do not fall back to old positions. Both investment HTTP and MCP reuse it.             |
| Cash-flow summary, audit and category detail | `CashFlowQueryService.report`, `categoryTransactions`                             | Load settings, candidates, rules and quotes once per period; derive all outputs from the evaluated report. `TransactionAnalysisService` adapts existing public methods.                                    |
| Home/history projection                      | `BalanceQueryService.loadBalanceProjection`                                       | Explicit user/date/account scope. Summary readers consume the projection without retaining a daily account matrix. Request `daily` or explicit `compact` history and honor work/output budgets.            |
| Provider apply                               | `TransactionService.processSyncResults`, investment upserts                       | Batch identities/rules/writes inside the apply transaction. Acquire investment generation before provider fetch; pass it to apply so stale work cannot publish.                                            |
| Settings/preferences                         | `UserService.findSettings`, `getPreferredCurrency`, `updateSettings`              | Narrow reads and locked patching. No singleton financial-data cache or cached revocation decision.                                                                                                         |

Keep HTTP minor-unit strings and MCP major-unit strings distinct. Do not convert
canonical financial values through JavaScript numbers to call these services.
Request-local reuse may share an `EntityManager`/quote set inside a read snapshot;
never retain one across users or requests. The standalone MCP listener uses Auth0;
PAT usage-write coalescing benefits the HTTP path only.
