import { Module } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { Reflector } from '@nestjs/core';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { ScheduleModule } from '@nestjs/schedule';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LoggerModule } from 'nestjs-pino';
import type { DestinationStream } from 'pino';
import { AccountActivityModule } from './account-activity/account-activity.module';
import { AccountModule } from './account/account.module';
import { AnalysisRuleModule } from './analysis-rule/analysis-rule.module';
import { AuthModule } from './auth/auth.module';
import { JwtAuthGuard } from './auth/guards/jwt-auth.guard';
import { PersonalAccessTokenService } from './auth/personal-access-token.service';
import { BalanceQueryModule } from './balance-query/balance-query.module';
import { BalanceSnapshotModule } from './balance-snapshot/balance-snapshot.module';
import { BankLinkModule } from './bank-link/bank-link.module';
import { CategoryModule } from './category/category.module';
import { CurrencyExchangeModule } from './currency-exchange/currency-exchange.module';
import { dataSourceOptions } from './data-source';
import { HealthModule } from './health/health.module';
import { InvestmentModule } from './investment/investment.module';
import { createSeqStream } from './logging/create-seq-stream';
import { McpModule } from './mcp/mcp.module';
import { NotificationModule } from './notification/notification.module';
import { RecurringManualTransactionModule } from './recurring-manual-transaction/recurring-manual-transaction.module';
import { TransactionAnalysisModule } from './transaction-analysis/transaction-analysis.module';
import { TransactionCategorizationModule } from './transaction-categorization/transaction-categorization.module';
import { TransactionModule } from './transaction/transaction.module';
import { UserModule } from './user/user.module';
import { getScheduleModuleOptions } from './schedule-options';
import { RequestMetricsModule } from './observability/request-metrics.module';

@Module({
  imports: [
    LoggerModule.forRootAsync({
      useFactory: async () => {
        const pino = await import('pino');

        // Build streams array - always include stdout for Docker/Coolify logs
        const streams: DestinationStream[] = [process.stdout];

        // Add Seq stream if configured
        if (process.env.SEQ_SERVER_URL) {
          const seqStream = await createSeqStream({
            serverUrl: process.env.SEQ_SERVER_URL,
            apiKey: process.env.SEQ_API_KEY,
          });
          streams.push(seqStream);
        }

        return {
          pinoHttp: {
            autoLogging: true,
            redact: {
              paths: [
                // Auth headers
                'req.headers.authorization',
                'req.headers.cookie',
                'res.headers["set-cookie"]',

                // Request body credentials
                'req.body.password',
                'req.body.token',
                'req.body.personalAccessToken',
                'req.body.refreshToken',
                'req.body.accessToken',
                'req.query.code',
                'req.query.state',
                'req.body.id_token',
                'req.body.client_secret',

                // Webhook verification headers
                'req.headers["plaid-verification"]',

                // Defense-in-depth for service-level logs
                '*.password',
                '*.tokenHash',
                '*.rawToken',
                '*.accessToken',
                '*.refreshToken',
                '*.idToken',
                '*.clientSecret',
                '*.code',
                '*.state',
                '*.userToken',
                '*.clientId',
                '*.public_tokens',
                '*.public_tokens[*]',
              ],
              censor: '[REDACTED]',
            },
            stream: pino.multistream(streams),
            level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
          },
        };
      },
    }),
    EventEmitterModule.forRoot(),
    ScheduleModule.forRoot(getScheduleModuleOptions()),
    AccountActivityModule,
    AuthModule,
    AccountModule,
    AnalysisRuleModule,
    BalanceQueryModule,
    BalanceSnapshotModule,
    BankLinkModule,
    CategoryModule,
    CurrencyExchangeModule,
    HealthModule,
    RequestMetricsModule,
    InvestmentModule,
    McpModule,
    NotificationModule,
    RecurringManualTransactionModule,
    TransactionAnalysisModule,
    TransactionCategorizationModule,
    TransactionModule,
    UserModule,
    TypeOrmModule.forRoot({
      ...dataSourceOptions,
    }),
  ],
  providers: [
    {
      provide: APP_GUARD,
      inject: [Reflector, PersonalAccessTokenService],
      useFactory: (
        reflector: Reflector,
        personalAccessTokenService: PersonalAccessTokenService,
      ) => new JwtAuthGuard(reflector, personalAccessTokenService),
    },
  ],
})
export class AppModule {}
