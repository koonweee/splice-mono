const fs = require('node:fs');
const path = require('node:path');
const { gunzipSync } = require('node:zlib');
const { createHash } = require('node:crypto');

const arg = (args, name, fallback) => {
  const at = args.indexOf(`--${name}`);
  return at < 0 ? fallback : args[at + 1];
};
const digest = (value) =>
  createHash('sha256').update(JSON.stringify(value)).digest('hex');
const assert = (condition, message) => {
  if (!condition) throw new Error(message);
};

// Text-only normalization preserves all exact digits; it never converts final money to Number.
function decimalText(value) {
  const match = /^(-?)(\d+)(?:\.(\d+))?(?:e([+-]?\d+))?$/i.exec(value);
  if (!match) return value;
  const exponent = Number(match[4] || 0);
  assert(
    Math.abs(exponent) <= 1000,
    'Unexpected decimal exponent in benchmark output',
  );
  let digits = match[2] + (match[3] || '');
  const point = match[2].length + exponent;
  if (point <= 0) digits = '0.' + '0'.repeat(-point) + digits;
  else if (point >= digits.length) digits += '0'.repeat(point - digits.length);
  else digits = digits.slice(0, point) + '.' + digits.slice(point);
  digits = digits
    .replace(/^0+(?=\d)/, '')
    .replace(/(\.\d*?)0+$/, '$1')
    .replace(/\.$/, '');
  return `${match[1] && digits !== '0' ? '-' : ''}${digits}`;
}

function normalize(value) {
  if (typeof value === 'number') {
    assert(Number.isFinite(value), 'Nonfinite benchmark output');
    return decimalText(String(value));
  }
  if (typeof value === 'string') return decimalText(value);
  if (Array.isArray(value)) return value.map(normalize);
  if (value && typeof value === 'object')
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .filter(
          (key) => !['createdAt', 'updatedAt', 'completedAt'].includes(key),
        )
        .map((key) => [key, normalize(value[key])]),
    );
  return value;
}

function structured(value) {
  return value.structuredContent ?? value;
}

const isHoldingsRead = name => name.startsWith('holdings.') || name.startsWith('extended.holdings.') || name === 'mcp.transport.holdings-20';

/** Only named contract additions are omitted. Financial values and transaction order remain. */
function economicProjection(name, input) {
  const value = structured(input);
  if (isHoldingsRead(name)) {
    assert(
      new Set(value.data.map((row) => row.id)).size === value.data.length,
      `${name}: duplicate holding IDs`,
    );
    return normalize({
      data: [...value.data].sort((a, b) => a.id.localeCompare(b.id)),
      query: value.query,
    });
  }
  if (name.includes('history.') || name === 'mcp.transport.history-month') {
    const { sampling, ...data } = value;
    return normalize(data);
  }
  if (name.includes('cashflow'))
    return normalize(value.app ? value.data : value);
  if (name.includes('transactions') && value.data) {
    if (name.includes('fx-') || name.startsWith('extended.transactions.'))
      return normalize({
        data: value.data,
        reportingCurrency: value.conversion.reportingCurrency,
        query: value.query,
      });
    if (name.startsWith('http.'))
      return normalize({
        data: value.data,
        total: value.total,
        pageSize: value.pageSize,
      });
  }
  return normalize(value);
}

function assertSame(before, after, name) {
  assert(
    digest(before) === digest(after),
    `Unexpected financial/selection difference: ${name}`,
  );
}

function validateOutput(name, beforeInput, afterInput, afterScenario) {
  const before = structured(beforeInput),
    after = structured(afterInput);
  if (name.startsWith('extended.cursor.')) {
    assert(
      after.total === null && after.hasMore === true && after.nextCursor,
      `${name}: missing count-free cursor continuation`,
    );
    assertSame(
      normalize(before.data),
      normalize(after.data),
      `${name}: ordered page data`,
    );
    return 'exact ordered deep-page data; initial count retained by caller, continuation omits count';
  }
  if (isHoldingsRead(name)) {
    const accounts = after.query.accountIds;
    assert(
      Array.isArray(after.snapshots) &&
        after.snapshots.length === accounts.length,
      `${name}: missing completed snapshot metadata`,
    );
    for (const account of accounts) {
      const snapshots = after.snapshots.filter(
        (row) => row.accountId === account,
      );
      assert(
        snapshots.length === 1 &&
          snapshots[0].snapshotDate === '2026-09-04' &&
          snapshots[0].holdingCount ===
            after.data.filter((row) => row.accountId === account).length,
        `${name}: incorrect empty/latest snapshot`,
      );
    }
  }
  if (name.includes('history.') || name === 'mcp.transport.history-month') {
    const compact = name.endsWith('.compact');
    assert(
      after.sampling?.resolution === (compact ? 'compact' : 'daily') &&
        after.sampling.sourcePointCount === before.chartData.length &&
        after.sampling.returnedPointCount === after.chartData.length,
      `${name}: incorrect sampling metadata`,
    );
    if (compact) {
      assert(
        after.chartData.length <= 122 && after.sampling.maxPoints === 122,
        `${name}: compact point budget`,
      );
      const source = new Map(
        before.chartData.map((point) => [point.date, point]),
      );
      after.chartData.forEach((point) =>
        assertSame(
          normalize(source.get(point.date)),
          normalize(point),
          `${name}/${point.date}`,
        ),
      );
      assertSame(
        normalize([before.chartData[0], before.chartData.at(-1)]),
        normalize([after.chartData[0], after.chartData.at(-1)]),
        `${name}: endpoints`,
      );
      assert(
        Buffer.byteLength(JSON.stringify(after.chartData)) <=
          Buffer.byteLength(JSON.stringify(before.chartData)) * 0.2,
        `${name}: compact chart bytes did not fall by 80%`,
      );
      assertSame(
        economicProjection(name, { ...before, chartData: [] }),
        economicProjection(name, { ...after, chartData: [] }),
        name,
      );
      return 'exact boundaries/accounts; selected original daily points; explicit compact chart';
    }
    if (name === 'shape.history.year.100-accounts.sparse-prior-fx.daily') {
      assert(
        before.chartData.every(
          (point) => String(point.value) === '115554.99999999999',
        ),
        `${name}: unexpected baseline correction input`,
      );
      assert(
        after.chartData.every((point) => point.value === '115555'),
        `${name}: exact EUR-to-USD projection is incorrect`,
      );
      assertSame(
        normalize(before.chartData.map(({ value, ...point }) => point)),
        normalize(after.chartData.map(({ value, ...point }) => point)),
        `${name}: dates and labels`,
      );
      assertSame(
        economicProjection(name, { ...before, chartData: [] }),
        economicProjection(name, { ...after, chartData: [] }),
        name,
      );
      return 'named baseline arithmetic correction: 115554.99999999999 → exact 115555; all integer totals, accounts, dates and labels unchanged';
    }
  }
  if (name.startsWith('extended.transactions.')) {
    assert(
      afterScenario.validation?.completeContinuationParity === true,
      `${name}: missing full continuation/SQL-oracle validation`,
    );
    assertSame(
      normalize(before.data.slice(0, after.data.length)),
      normalize(after.data),
      `${name}: first-call selection prefix`,
    );
    if (after.pageInfo.hasMore)
      assert(
        after.pageInfo.continuationReason === 'scan_budget' &&
          after.pageInfo.nextCursor,
        `${name}: dishonest scan continuation`,
      );
    return 'bounded first call; full advancing continuation checked against ordered SQL oracle';
  }
  if (name.includes('fx-')) {
    assert(
      after.pageInfo.hasMore === false && after.pageInfo.nextCursor === null,
      `${name}: full final page continuation`,
    );
    for (const rate of after.conversion.rates) {
      assert(
        rate.requestedDate &&
          rate.rateDate &&
          typeof rate.rate === 'string' &&
          ['DB', 'FORWARD_FILLED', 'BACKWARD_FILLED', 'IDENTITY'].includes(
            rate.source,
          ),
        `${name}: missing exact FX provenance`,
      );
      if (rate.source === 'FORWARD_FILLED')
        assert(
          rate.rateDate < rate.requestedDate,
          `${name}: incorrect prior quote provenance`,
        );
      if (rate.source === 'DB')
        assert(
          rate.rateDate === rate.requestedDate,
          `${name}: incorrect exact quote provenance`,
        );
    }
  }
  assertSame(
    economicProjection(name, beforeInput),
    economicProjection(name, afterInput),
    name,
  );
  return 'exact economic/selection parity after documented representation and metadata changes';
}

function queryBudget(name) {
  if (name.startsWith('matching.')) return 0;
  if (name.startsWith('holdings.') || name.startsWith('extended.holdings.'))
    return 3;
  if (name === 'mcp.transport.holdings-20') return 4;
  if (name.startsWith('mcp-transactions.fx-')) return 4;
  if (name === 'mcp.transport.transactions.fx-100') return 5;
  if (name.startsWith('transactions.')) return 3;
  if (name.startsWith('extended.cursor.')) return 2;
  if (name.includes('history.')) return 7;
  if (name === 'mcp.transport.history-month') return 8;
  if (name.startsWith('cashflow.') || name.startsWith('shape.cashflow.'))
    return 4;
  if (name === 'mcp.transport.cashflow-comparison') return 9;
  const banking = /^sync\.banking(?:-modified)?\.(\d+)\./.exec(name);
  if (banking) return Math.ceil(Number(banking[1]) / 250) + 3;
  const investment = /^sync\.investment-transactions\.(\d+)$/.exec(name);
  if (investment) return Math.ceil(Number(investment[1]) / 300) + 3;
  return null;
}

function loadOutput(directory, scenario) {
  assert(
    scenario.outputArtifact,
    `Missing original-output evidence: ${scenario.name}`,
  );
  const target = path.resolve(directory, scenario.outputArtifact);
  assert(
    target.startsWith(path.resolve(directory) + path.sep),
    'Output evidence must stay within benchmark artifacts',
  );
  return JSON.parse(gunzipSync(fs.readFileSync(target)));
}

function compareReports(
  before,
  after,
  directory,
  { exploratory = false } = {},
) {
  assert(
    before.completed &&
      after.completed &&
      before.fixtureHash === after.fixtureHash &&
      JSON.stringify(before.environment) === JSON.stringify(after.environment),
    'Incomplete or mismatched benchmark inputs',
  );
  assert(
    exploratory ||
      (before.samples >= 100 &&
        after.samples >= 100 &&
        before.warmups >= 5 &&
        after.warmups >= 5),
    'Final comparison requires 100 samples and 5 warmups',
  );
  return before.scenarios.map((old) => {
    const next = after.scenarios.find((scenario) => scenario.name === old.name);
    assert(
      next && !next.baselineFailure,
      `Missing/failed final scenario ${old.name}`,
    );
    if (old.baselineFailure)
      return {
        name: old.name,
        rows: before.fixture.rows,
        run: before.run,
        baselineFailure: old.baselineFailure,
        corrected: true,
      };
    const semanticValidation = validateOutput(
      old.name,
      loadOutput(directory, old),
      loadOutput(directory, next),
      next,
    );
    const budget = queryBudget(old.name);
    if (old.name.startsWith('extended.cursor.'))
      assert(
        after.plans[old.name].every(
          (statement) => !/\bOFFSET\b|\bCOUNT\s*\(/i.test(statement.sql),
        ),
        `${old.name}: continuation performed an offset/count query`,
      );
    assert(
      budget === null || next.raw.every((sample) => sample.sqlCount <= budget),
      `${old.name}: SELECT budget ${budget} exceeded`,
    );
    if (old.name.includes('fx-'))
      assert(
        next.raw.every(
          (sample) => sample.fxSelects === undefined || sample.fxSelects <= 3,
        ),
        `${old.name}: FX SELECT budget exceeded`,
      );
    if (old.name.startsWith('sync.banking'))
      assert(
        next.raw.every(
          (sample) =>
            sample.categorizationRuleSelects === undefined ||
            sample.categorizationRuleSelects <= 1,
        ),
        `${old.name}: rules were loaded per row`,
      );
    const regression = ['p50', 'p95'].filter(
      (percentile) =>
        next.latencyMs[percentile] - old.latencyMs[percentile] > 5 &&
        next.latencyMs[percentile] > old.latencyMs[percentile] * 1.1,
    );
    return {
      name: old.name,
      rows: before.fixture.rows,
      run: before.run,
      policy: old.policy,
      semanticValidation,
      before: old.latencyMs,
      after: next.latencyMs,
      beforeCpu: old.cpuMs,
      afterCpu: next.cpuMs,
      p50ImprovementPercent: 100 * (1 - next.latencyMs.p50 / old.latencyMs.p50),
      p95ImprovementPercent: 100 * (1 - next.latencyMs.p95 / old.latencyMs.p95),
      beforeQueries: old.raw[0].sqlCount,
      afterQueries: next.raw[0].sqlCount,
      beforeBytes: old.raw[0].responseBytes,
      afterBytes: next.raw[0].responseBytes,
      beforeGzipBytes: old.raw[0].gzipBytes,
      afterGzipBytes: next.raw[0].gzipBytes,
      beforeSqlBytes: old.raw[0].sqlBytes,
      afterSqlBytes: next.raw[0].sqlBytes,
      queryBudget: budget,
      regression,
    };
  });
}

function summaries(comparisons) {
  const groups = new Map();
  for (const value of comparisons) {
    const key = `${value.rows}/${value.name}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(value);
  }
  const median = (values) =>
    [...values].sort((a, b) => a - b)[Math.floor(values.length / 2)];
  const spread = (values) => ({
    median: median(values),
    min: Math.min(...values),
    max: Math.max(...values),
  });
  return [...groups.values()].map((runs) =>
    runs[0].baselineFailure
      ? {
          name: runs[0].name,
          rows: runs[0].rows,
          runs: runs.length,
          baselineFailure: runs[0].baselineFailure,
          corrected: runs.every((run) => run.corrected),
        }
      : {
          name: runs[0].name,
          rows: runs[0].rows,
          runs: runs.length,
          p50Before: spread(runs.map((run) => run.before.p50)),
          p50After: spread(runs.map((run) => run.after.p50)),
          p95Before: spread(runs.map((run) => run.before.p95)),
          p95After: spread(runs.map((run) => run.after.p95)),
          cpuMedianBefore: median(runs.map((run) => run.beforeCpu.p50)),
          cpuMedianAfter: median(runs.map((run) => run.afterCpu.p50)),
          queriesBefore: runs[0].beforeQueries,
          queriesAfter: runs[0].afterQueries,
          bytesBefore: runs[0].beforeBytes,
          bytesAfter: runs[0].afterBytes,
          regressionRuns: runs
            .filter((run) => run.regression.length)
            .map((run) => run.run),
        },
  );
}

async function compare(args) {
  const directory = path.resolve(
    arg(
      args,
      'output',
      path.join(__dirname, '../../docs/performance/backend-query'),
    ),
  );
  const suite = arg(args, 'suite', directory === path.resolve(__dirname, '../../docs/performance/backend-query') ? 'all' : 'directory');
  if (suite === 'all') return require('./compare-all.cjs').compareAll(directory);
  const reports = fs
    .readdirSync(directory)
    .filter((file) => /^(before|after)-\d+-run\d+\.json$/.test(file))
    .map((file) =>
      JSON.parse(fs.readFileSync(path.join(directory, file), 'utf8')),
    );
  const exploratory = args.includes('--exploratory');
  const comparisons = [];
  for (const before of reports.filter(
    (report) => report.variant === 'before',
  )) {
    const after = reports.find(
      (report) =>
        report.variant === 'after' &&
        report.fixture.rows === before.fixture.rows &&
        report.run === before.run,
    );
    assert(
      after,
      `Missing after capture for ${before.fixture.rows} run ${before.run}`,
    );
    comparisons.push(
      ...compareReports(before, after, directory, { exploratory }),
    );
  }
  assert(comparisons.length, 'No complete comparison pairs');
  const summary = summaries(comparisons);
  assert(
    exploratory || summary.every((row) => row.runs === 3),
    'Final comparisons require three independent process runs per shape',
  );
  fs.writeFileSync(
    path.join(directory, 'comparison.json'),
    JSON.stringify({ exploratory, comparisons, summary }, null, 2) + '\n',
  );
  const table = [
    '| Scenario | Rows | p50 before → after (ms) | p95 before → after (ms) | SELECTs | JSON bytes |',
    '| --- | ---: | ---: | ---: | ---: | ---: |',
  ];
  for (const row of summary)
    table.push(
      row.baselineFailure
        ? `| ${row.name} | ${row.rows} | Baseline failed; corrected | — | — | — |`
        : `| ${row.name} | ${row.rows} | ${row.p50Before.median.toFixed(2)} → ${row.p50After.median.toFixed(2)} | ${row.p95Before.median.toFixed(2)} → ${row.p95After.median.toFixed(2)} | ${row.queriesBefore} → ${row.queriesAfter} | ${row.bytesBefore} → ${row.bytesAfter} |`,
    );
  fs.writeFileSync(
    path.join(directory, 'comparison.md'),
    `${exploratory ? 'Exploratory only. ' : ''}Median of each independent process run’s percentiles; spread and regressions are retained in comparison.json.\n\n${table.join('\n')}\n`,
  );
  console.log(
    `Compared ${comparisons.length} scenario/run pairs; ${summary.filter((row) => row.regressionRuns?.length).length} shapes require regression review.`,
  );
}

module.exports = {
  compare,
  compareReports,
  decimalText,
  economicProjection,
  normalize,
  queryBudget,
  summaries,
  validateOutput,
};
