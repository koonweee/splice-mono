import { defineConfig } from 'orval'

export default defineConfig({
  api: {
    input: process.env.ORVAL_API_INPUT ?? 'http://localhost:3000/api-json',
    output: {
      target: './src/api/clients',
      schemas: './src/api/models',
      client: 'react-query',
      clean: true,
      override: {
        mutator: {
          path: './src/api/axios.ts',
          name: 'axios',
        },
      },
    },
  },
})
