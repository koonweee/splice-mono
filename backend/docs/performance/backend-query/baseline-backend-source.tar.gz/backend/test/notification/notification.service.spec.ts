import { NotificationPushDeliveryEntity } from '../../src/notification/notification-push-delivery.entity';
import { NotificationEntity } from '../../src/notification/notification.entity';
import { NotificationService } from '../../src/notification/notification.service';
import { PushSubscriptionEntity } from '../../src/notification/push-subscription.entity';
import type { User } from '../../src/types/User';
import type { UserSettings } from '../../src/types/UserSettings';

const userId = '00000000-0000-4000-8000-000000000001';
const transactionId = '00000000-0000-4000-8000-000000000101';
const accountId = '00000000-0000-4000-8000-000000000201';

const enabledSettings: UserSettings = {
  currency: 'USD',
  timezone: 'UTC',
  hideZeroBalanceAccounts: false,
  theme: 'splice-dark',
  neutralizationLookaroundDays: 60,
  analysisSankeyEnabled: false,
  notifications: {
    transactions: {
      newSyncedTransactions: true,
    },
    bankLinks: {
      needsAttention: true,
    },
  },
};

function buildUser(settings: UserSettings): User {
  return {
    id: userId,
    email: 'user@example.com',
    settings,
    createdAt: new Date('2026-01-01T00:00:00.000Z'),
    updatedAt: new Date('2026-01-01T00:00:00.000Z'),
  };
}

function buildSubscription(id: string): PushSubscriptionEntity {
  const entity = new PushSubscriptionEntity();
  entity.id = id;
  entity.userId = userId;
  entity.endpoint = `https://push.example.com/${id}`;
  entity.p256dh = 'p256dh';
  entity.auth = 'auth';
  entity.userAgent = 'test';
  entity.revokedAt = null;
  entity.createdAt = new Date('2026-01-01T00:00:00.000Z');
  entity.updatedAt = new Date('2026-01-01T00:00:00.000Z');
  return entity;
}

describe('NotificationService', () => {
  const pushSubscriptionTransactionQuery = jest.fn();
  const notificationRepository = {
    manager: {
      transaction: jest.fn(),
    },
    save: jest.fn(),
    createQueryBuilder: jest.fn(),
    delete: jest.fn(),
  };
  const pushSubscriptionRepository = {
    manager: {
      transaction: jest.fn(),
    },
    findOne: jest.fn(),
    find: jest.fn(),
    save: jest.fn(),
    createQueryBuilder: jest.fn(),
  };
  const pushDeliveryRepository = {
    manager: {
      transaction: jest.fn(),
    },
    save: jest.fn(),
    delete: jest.fn(),
    createQueryBuilder: jest.fn(),
    find: jest.fn(),
    findOne: jest.fn(),
    update: jest.fn(),
  };
  const userService = {
    findOne: jest.fn(),
    enableDefaultNotificationsIfUnset: jest.fn(),
  };
  const webPushAdapter = {
    isConfigured: jest.fn(),
    getPublicKey: jest.fn(),
    send: jest.fn(),
  };

  let service: NotificationService;

  beforeEach(() => {
    jest.clearAllMocks();
    pushSubscriptionTransactionQuery.mockResolvedValue([]);
    pushSubscriptionRepository.manager.transaction.mockImplementation(
      async (callback) =>
        callback({
          query: pushSubscriptionTransactionQuery,
          getRepository: (entity: unknown) =>
            entity === PushSubscriptionEntity
              ? pushSubscriptionRepository
              : pushDeliveryRepository,
        }),
    );
    pushDeliveryRepository.manager.transaction.mockImplementation(
      async (callback) =>
        callback({
          query: jest
            .fn()
            .mockResolvedValue([{ id: 'delivery-id', ownersMatch: true }]),
          getRepository: (entity: unknown) =>
            entity === PushSubscriptionEntity
              ? pushSubscriptionRepository
              : pushDeliveryRepository,
        }),
    );
    service = new NotificationService(
      notificationRepository as never,
      pushSubscriptionRepository as never,
      pushDeliveryRepository as never,
      userService as never,
      webPushAdapter as never,
    );
  });

  it('locks and cancels old-owner pending work before reassigning an endpoint', async () => {
    const subscription = buildSubscription('subscription-id');
    subscription.userId = 'old-user-id';
    subscription.endpoint = 'https://push.example.com/shared';
    pushSubscriptionRepository.findOne.mockResolvedValueOnce(subscription);
    pushSubscriptionRepository.save.mockImplementation((entity) =>
      Promise.resolve(entity),
    );
    pushSubscriptionTransactionQuery
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([{ id: 'pending-delivery', status: 'pending' }]);
    pushDeliveryRepository.update.mockResolvedValueOnce({ affected: 2 });

    await service.registerPushSubscription(userId, {
      endpoint: subscription.endpoint,
      keys: { p256dh: 'new-key', auth: 'new-auth' },
      userAgent: 'new browser',
    });

    expect(pushDeliveryRepository.update).toHaveBeenCalledWith(
      {
        id: expect.objectContaining({ _type: 'in' }),
        status: expect.objectContaining({ _type: 'in' }),
      },
      expect.objectContaining({
        status: 'failed',
        lastError: 'Push endpoint ownership changed',
      }),
    );
    expect(subscription.userId).toBe('old-user-id');
    expect(subscription.revokedAt).toBeInstanceOf(Date);
    expect(subscription.endpoint).toMatch(/^reassigned:subscription-id:/);
    const newSubscription = pushSubscriptionRepository.save.mock.calls[1][0];
    expect(newSubscription.userId).toBe(userId);
    expect(newSubscription.endpoint).toBe('https://push.example.com/shared');
    expect(newSubscription.p256dh).toBe('new-key');
    expect(pushSubscriptionTransactionQuery.mock.calls[1][0]).toContain(
      'FOR UPDATE OF delivery',
    );
  });

  it('refuses cross-owner reassignment while a legacy worker may be sending', async () => {
    const subscription = buildSubscription('subscription-id');
    subscription.userId = 'old-user-id';
    subscription.endpoint = 'https://push.example.com/shared';
    pushSubscriptionRepository.findOne.mockResolvedValueOnce(subscription);
    pushSubscriptionTransactionQuery
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([
        {
          id: 'processing-delivery',
          status: 'processing',
          processingStartedAt: new Date(),
        },
      ]);

    await expect(
      service.registerPushSubscription(userId, {
        endpoint: subscription.endpoint,
        keys: { p256dh: 'new-key', auth: 'new-auth' },
        userAgent: 'new browser',
      }),
    ).rejects.toThrow(
      'Push subscription is currently delivering a notification; retry registration shortly',
    );

    expect(pushDeliveryRepository.update).not.toHaveBeenCalled();
    expect(pushSubscriptionRepository.save).not.toHaveBeenCalled();
    expect(subscription.userId).toBe('old-user-id');
    expect(subscription.p256dh).toBe('p256dh');
  });

  it('leaves late legacy deliveries attached to a revoked old-owner tombstone', async () => {
    const subscription = buildSubscription('subscription-id');
    subscription.userId = 'old-user-id';
    subscription.endpoint = 'https://push.example.com/shared';
    pushSubscriptionRepository.findOne.mockResolvedValueOnce(subscription);
    pushSubscriptionRepository.save.mockImplementation((entity) =>
      Promise.resolve(entity),
    );
    pushSubscriptionTransactionQuery
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([]);

    await service.registerPushSubscription(userId, {
      endpoint: 'https://push.example.com/shared',
      keys: { p256dh: 'new-key', auth: 'new-auth' },
    });

    const tombstone = pushSubscriptionRepository.save.mock.calls[0][0];
    const replacement = pushSubscriptionRepository.save.mock.calls[1][0];
    expect(tombstone.id).toBe('subscription-id');
    expect(tombstone.userId).toBe('old-user-id');
    expect(tombstone.revokedAt).toBeInstanceOf(Date);
    expect(tombstone.endpoint).not.toBe('https://push.example.com/shared');
    expect(replacement).not.toBe(tombstone);
    expect(replacement.userId).toBe(userId);
    expect(replacement.endpoint).toBe('https://push.example.com/shared');
    expect(replacement.revokedAt).toBeNull();
  });

  it('terminalizes stale processing work before transferring an endpoint', async () => {
    const subscription = buildSubscription('subscription-id');
    subscription.userId = 'old-user-id';
    subscription.endpoint = 'https://push.example.com/shared';
    pushSubscriptionRepository.findOne.mockResolvedValueOnce(subscription);
    pushSubscriptionRepository.save.mockImplementation((entity) =>
      Promise.resolve(entity),
    );
    pushSubscriptionTransactionQuery
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([
        {
          id: 'stale-processing-delivery',
          status: 'processing',
          processingStartedAt: new Date(Date.now() - 11 * 60 * 1000),
        },
      ]);
    pushDeliveryRepository.update.mockResolvedValueOnce({ affected: 1 });

    await service.registerPushSubscription(userId, {
      endpoint: subscription.endpoint,
      keys: { p256dh: 'new-key', auth: 'new-auth' },
    });

    expect(pushDeliveryRepository.update).toHaveBeenCalledWith(
      {
        id: expect.objectContaining({ _type: 'in' }),
        status: expect.objectContaining({ _type: 'in' }),
      },
      expect.objectContaining({
        status: 'failed',
        processingStartedAt: null,
        lastError: 'Push endpoint ownership changed',
      }),
    );
    expect(subscription.revokedAt).toBeInstanceOf(Date);
    expect(pushSubscriptionRepository.save).toHaveBeenCalledTimes(2);
  });

  it('revokes under the endpoint lock and terminalizes only abandoned work', async () => {
    const subscription = buildSubscription('subscription-id');
    pushSubscriptionRepository.findOne.mockResolvedValueOnce(subscription);
    pushSubscriptionRepository.save.mockImplementation((entity) =>
      Promise.resolve(entity),
    );
    pushSubscriptionTransactionQuery
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([
        { id: 'pending-delivery' },
        { id: 'stale-processing-delivery' },
      ]);
    pushDeliveryRepository.update.mockResolvedValueOnce({ affected: 2 });

    await expect(
      service.revokeCurrentPushSubscription(userId, subscription.endpoint),
    ).resolves.toBe(true);

    expect(pushSubscriptionTransactionQuery.mock.calls[0][0]).toContain(
      'pg_advisory_xact_lock',
    );
    expect(pushSubscriptionTransactionQuery.mock.calls[1][0]).toContain(
      'delivery."processingStartedAt" <= $2',
    );
    expect(pushDeliveryRepository.update).toHaveBeenCalledWith(
      expect.objectContaining({
        id: expect.objectContaining({ _type: 'in' }),
      }),
      expect.objectContaining({
        status: 'failed',
        lastError: 'Push subscription revoked',
      }),
    );
    expect(subscription.revokedAt).toBeInstanceOf(Date);
  });

  it('revokes all subscriptions after locking their endpoints in order', async () => {
    const subscriptions = [
      buildSubscription('subscription-a'),
      buildSubscription('subscription-b'),
    ];
    subscriptions[0].endpoint = 'https://push.example.com/a';
    subscriptions[1].endpoint = 'https://push.example.com/b';
    pushSubscriptionRepository.find.mockResolvedValueOnce(subscriptions);
    pushSubscriptionRepository.save.mockImplementation((entities) =>
      Promise.resolve(entities),
    );
    pushSubscriptionTransactionQuery
      .mockResolvedValueOnce(
        subscriptions.map(({ endpoint }) => ({ endpoint })),
      )
      .mockResolvedValueOnce([])
      .mockResolvedValueOnce([{ id: 'pending-delivery' }]);
    pushDeliveryRepository.update.mockResolvedValueOnce({ affected: 1 });

    await expect(service.revokeAllPushSubscriptions(userId)).resolves.toBe(2);

    expect(pushSubscriptionTransactionQuery.mock.calls[1][0]).toContain(
      'pg_advisory_xact_lock',
    );
    expect(pushSubscriptionTransactionQuery.mock.calls[1][1]).toEqual([
      subscriptions.map(({ endpoint }) => endpoint),
    ]);
    expect(pushSubscriptionRepository.find).toHaveBeenCalledWith(
      expect.objectContaining({
        order: { endpoint: 'ASC' },
        lock: { mode: 'pessimistic_write' },
      }),
    );
    expect(subscriptions.every(({ revokedAt }) => revokedAt !== null)).toBe(
      true,
    );
    expect(pushDeliveryRepository.update).toHaveBeenCalledWith(
      expect.objectContaining({ id: expect.objectContaining({ _type: 'in' }) }),
      expect.objectContaining({ lastError: 'Push subscription revoked' }),
    );
  });

  it('preserves same-owner subscription refreshes while a delivery is processing', async () => {
    const subscription = buildSubscription('subscription-id');
    subscription.endpoint = 'https://push.example.com/shared';
    pushSubscriptionRepository.findOne.mockResolvedValueOnce(subscription);
    pushSubscriptionRepository.save.mockImplementationOnce((entity) =>
      Promise.resolve(entity),
    );

    await service.registerPushSubscription(userId, {
      endpoint: subscription.endpoint,
      keys: { p256dh: 'refreshed-key', auth: 'refreshed-auth' },
      userAgent: 'new browser',
    });

    // Only the endpoint advisory lock runs; delivery fencing is necessary
    // solely when ownership crosses users.
    expect(pushSubscriptionTransactionQuery).toHaveBeenCalledTimes(1);
    expect(pushDeliveryRepository.update).not.toHaveBeenCalled();
    expect(subscription.userId).toBe(userId);
    expect(subscription.p256dh).toBe('refreshed-key');
  });

  it('skips canonical notification creation when type preference is disabled', async () => {
    userService.findOne.mockResolvedValueOnce(
      buildUser({
        ...enabledSettings,
        notifications: {
          transactions: {
            newSyncedTransactions: false,
          },
          bankLinks: {
            needsAttention: true,
          },
        },
      }),
    );

    await expect(
      service.createNewSyncedTransactionsNotification({
        userId,
        transactionIds: [transactionId],
        accountIds: [accountId],
        count: 1,
        occurredAt: '2026-01-01T00:00:00.000Z',
      }),
    ).resolves.toBeNull();

    expect(notificationRepository.manager.transaction).not.toHaveBeenCalled();
  });

  it('creates a canonical notification without push deliveries when no subscriptions exist', async () => {
    const savedNotification = new NotificationEntity();
    savedNotification.id = '00000000-0000-4000-8000-000000000301';
    savedNotification.userId = userId;
    savedNotification.type = 'transactions.new_synced';
    savedNotification.dedupeKey = 'dedupe';
    savedNotification.payload = {
      count: 1,
      transactionIds: [transactionId],
      accountIds: [accountId],
      occurredAt: '2026-01-01T00:00:00.000Z',
    };
    savedNotification.status = 'active';
    savedNotification.readAt = null;
    savedNotification.archivedAt = null;
    savedNotification.createdAt = new Date('2026-01-01T00:00:00.000Z');
    savedNotification.updatedAt = new Date('2026-01-01T00:00:00.000Z');

    const notificationRepo = {
      save: jest.fn().mockResolvedValue(savedNotification),
    };
    const subscriptionRepo = {
      find: jest.fn().mockResolvedValue([]),
    };
    const deliveryRepo = {
      save: jest.fn(),
    };

    userService.findOne.mockResolvedValueOnce(buildUser(enabledSettings));
    webPushAdapter.isConfigured.mockReturnValue(true);
    notificationRepository.manager.transaction.mockImplementationOnce(
      async (
        callback: (manager: {
          getRepository: (entity: unknown) => unknown;
        }) => unknown,
      ) =>
        callback({
          getRepository: (entity: unknown) => {
            if (entity === NotificationEntity) return notificationRepo;
            if (entity === PushSubscriptionEntity) return subscriptionRepo;
            return deliveryRepo;
          },
        }),
    );

    const result = await service.createNewSyncedTransactionsNotification({
      userId,
      transactionIds: [transactionId],
      accountIds: [accountId],
      count: 1,
      occurredAt: '2026-01-01T00:00:00.000Z',
    });

    expect(result?.id).toBe(savedNotification.id);
    expect(deliveryRepo.save).not.toHaveBeenCalled();
  });

  it('creates push delivery rows for each active subscription', async () => {
    const savedNotification = new NotificationEntity();
    savedNotification.id = '00000000-0000-4000-8000-000000000301';
    savedNotification.userId = userId;
    savedNotification.type = 'transactions.new_synced';
    savedNotification.dedupeKey = 'dedupe';
    savedNotification.payload = {
      count: 2,
      transactionIds: [transactionId],
      accountIds: [accountId],
      occurredAt: '2026-01-01T00:00:00.000Z',
    };
    savedNotification.status = 'active';
    savedNotification.readAt = null;
    savedNotification.archivedAt = null;
    savedNotification.createdAt = new Date('2026-01-01T00:00:00.000Z');
    savedNotification.updatedAt = new Date('2026-01-01T00:00:00.000Z');

    const subscriptions = [
      buildSubscription('00000000-0000-4000-8000-000000000401'),
      buildSubscription('00000000-0000-4000-8000-000000000402'),
    ];
    const notificationRepo = {
      save: jest.fn().mockResolvedValue(savedNotification),
    };
    const subscriptionRepo = {
      find: jest.fn().mockResolvedValue(subscriptions),
    };
    const deliveryRepo = {
      save: jest.fn().mockResolvedValue([]),
    };

    userService.findOne.mockResolvedValueOnce(buildUser(enabledSettings));
    webPushAdapter.isConfigured.mockReturnValue(true);
    notificationRepository.manager.transaction.mockImplementationOnce(
      async (
        callback: (manager: {
          getRepository: (entity: unknown) => unknown;
        }) => unknown,
      ) =>
        callback({
          getRepository: (entity: unknown) => {
            if (entity === NotificationEntity) return notificationRepo;
            if (entity === PushSubscriptionEntity) return subscriptionRepo;
            return deliveryRepo;
          },
        }),
    );

    await service.createNewSyncedTransactionsNotification({
      userId,
      transactionIds: [transactionId],
      accountIds: [accountId],
      count: 2,
      occurredAt: '2026-01-01T00:00:00.000Z',
    });

    const deliveries = deliveryRepo.save.mock
      .calls[0][0] as NotificationPushDeliveryEntity[];
    expect(deliveries).toHaveLength(2);
    expect(deliveries.map((delivery) => delivery.subscriptionId)).toEqual(
      subscriptions.map((subscription) => subscription.id),
    );
  });

  it('treats dedupe unique conflicts as idempotent no-ops', async () => {
    userService.findOne.mockResolvedValueOnce(buildUser(enabledSettings));
    notificationRepository.manager.transaction.mockRejectedValueOnce({
      code: '23505',
    });

    await expect(
      service.createNewSyncedTransactionsNotification({
        userId,
        transactionIds: [transactionId],
        accountIds: [accountId],
        count: 1,
        occurredAt: '2026-01-01T00:00:00.000Z',
      }),
    ).resolves.toBeNull();
  });

  it('renders uncategorized transaction push payloads', () => {
    const notification = new NotificationEntity();
    notification.id = '00000000-0000-4000-8000-000000000301';
    notification.type = 'transactions.new_synced';
    notification.payload = {
      count: 3,
      transactionIds: [transactionId],
      accountIds: [accountId],
      occurredAt: '2026-01-01T00:00:00.000Z',
    };

    expect(service.renderPushPayload(notification)).toEqual({
      title: 'New uncategorized transactions',
      body: '3 new uncategorized transactions were added',
      url: '/transactions?categoryId=UNCATEGORIZED',
      tag: notification.id,
      badgeCount: 3,
    });
  });

  it('skips bank link needs attention notification creation when preference is disabled', async () => {
    userService.findOne.mockResolvedValueOnce(
      buildUser({
        ...enabledSettings,
        notifications: {
          transactions: {
            newSyncedTransactions: true,
          },
          bankLinks: {
            needsAttention: false,
          },
        },
      }),
    );

    await expect(
      service.createBankLinkNeedsAttentionNotification({
        userId,
        bankLinkId: '00000000-0000-4000-8000-000000000501',
        providerName: 'plaid',
        institutionName: 'Chase',
        status: 'ERROR',
        statusBody: { error_code: 'ITEM_LOGIN_REQUIRED' },
        occurredAt: '2026-01-01T00:00:00.000Z',
      }),
    ).resolves.toBeNull();

    expect(notificationRepository.manager.transaction).not.toHaveBeenCalled();
  });

  it('renders bank link needs attention push payloads with an accounts deep link', () => {
    const notification = new NotificationEntity();
    notification.id = '00000000-0000-4000-8000-000000000501';
    notification.type = 'bank_link.needs_attention';
    notification.payload = {
      bankLinkId: '00000000-0000-4000-8000-000000000601',
      providerName: 'plaid',
      institutionName: 'Chase',
      status: 'PENDING_REAUTH',
      statusBody: { reason: 'pending_expiration' },
      occurredAt: '2026-01-01T00:00:00.000Z',
    };

    expect(service.renderPushPayload(notification)).toEqual({
      title: 'Chase needs attention',
      body: 'Reconnect this account to keep Splice syncing.',
      url: '/accounts',
      tag: notification.id,
    });
  });

  it('creates a test notification and queues active subscription deliveries', async () => {
    const savedNotification = new NotificationEntity();
    savedNotification.id = '00000000-0000-4000-8000-000000000302';
    savedNotification.userId = userId;
    savedNotification.type = 'system.test';
    savedNotification.dedupeKey = 'system.test:dedupe';
    savedNotification.payload = {
      occurredAt: '2026-01-01T00:00:00.000Z',
    };
    savedNotification.status = 'active';
    savedNotification.readAt = null;
    savedNotification.archivedAt = null;
    savedNotification.createdAt = new Date('2026-01-01T00:00:00.000Z');
    savedNotification.updatedAt = new Date('2026-01-01T00:00:00.000Z');

    const subscriptions = [
      buildSubscription('00000000-0000-4000-8000-000000000401'),
    ];
    const notificationRepo = {
      save: jest.fn().mockResolvedValue(savedNotification),
    };
    const subscriptionRepo = {
      find: jest.fn().mockResolvedValue(subscriptions),
    };
    const deliveryRepo = {
      save: jest.fn().mockResolvedValue([]),
    };

    webPushAdapter.isConfigured.mockReturnValue(true);
    notificationRepository.manager.transaction.mockImplementationOnce(
      async (
        callback: (manager: {
          getRepository: (entity: unknown) => unknown;
        }) => unknown,
      ) =>
        callback({
          getRepository: (entity: unknown) => {
            if (entity === NotificationEntity) return notificationRepo;
            if (entity === PushSubscriptionEntity) return subscriptionRepo;
            return deliveryRepo;
          },
        }),
    );

    const result = await service.createTestNotification(userId);

    expect(result).toMatchObject({
      deliveryCount: 1,
      pushConfigured: true,
      notification: {
        id: savedNotification.id,
        type: 'system.test',
      },
    });
    expect(deliveryRepo.save).toHaveBeenCalledWith([
      expect.objectContaining({
        notificationId: savedNotification.id,
        subscriptionId: subscriptions[0].id,
        status: 'pending',
      }),
    ]);
  });

  it('renders test notification push payloads', () => {
    const notification = new NotificationEntity();
    notification.id = '00000000-0000-4000-8000-000000000302';
    notification.type = 'system.test';
    notification.payload = {
      occurredAt: '2026-01-01T00:00:00.000Z',
    };

    expect(service.renderPushPayload(notification)).toEqual({
      title: 'Splice test notification',
      body: 'Push notifications are working.',
      url: '/settings?tab=notifications',
      tag: notification.id,
    });
  });

  it('revokes expired subscriptions on web push 410 responses', async () => {
    const delivery = new NotificationPushDeliveryEntity();
    delivery.id = '00000000-0000-4000-8000-000000000501';
    delivery.status = 'processing';
    delivery.attemptCount = 1;
    delivery.notification = new NotificationEntity();
    delivery.notification.id = '00000000-0000-4000-8000-000000000301';
    delivery.notification.userId = userId;
    delivery.notification.type = 'transactions.new_synced';
    delivery.notification.payload = {
      count: 1,
      transactionIds: [transactionId],
      accountIds: [accountId],
      occurredAt: '2026-01-01T00:00:00.000Z',
    };
    delivery.subscription = buildSubscription(
      '00000000-0000-4000-8000-000000000401',
    );
    webPushAdapter.send.mockRejectedValueOnce({
      statusCode: 410,
      message: 'Gone',
    });
    pushSubscriptionRepository.save.mockResolvedValueOnce(
      delivery.subscription,
    );
    pushDeliveryRepository.save.mockResolvedValueOnce(delivery);
    pushDeliveryRepository.findOne.mockResolvedValueOnce(delivery);

    await service.sendPushDelivery(delivery);

    expect(delivery.status).toBe('failed');
    expect(delivery.subscription.revokedAt).toBeInstanceOf(Date);
    expect(pushSubscriptionRepository.save).toHaveBeenCalledWith(
      delivery.subscription,
    );
  });

  it('retries transient push failures and caps attempts', async () => {
    const delivery = new NotificationPushDeliveryEntity();
    delivery.id = '00000000-0000-4000-8000-000000000501';
    delivery.status = 'processing';
    delivery.attemptCount = 1;
    delivery.notification = new NotificationEntity();
    delivery.notification.id = '00000000-0000-4000-8000-000000000301';
    delivery.notification.userId = userId;
    delivery.notification.type = 'transactions.new_synced';
    delivery.notification.payload = {
      count: 1,
      transactionIds: [transactionId],
      accountIds: [accountId],
      occurredAt: '2026-01-01T00:00:00.000Z',
    };
    delivery.subscription = buildSubscription(
      '00000000-0000-4000-8000-000000000401',
    );
    webPushAdapter.send.mockRejectedValueOnce(new Error('temporary'));
    pushDeliveryRepository.save.mockResolvedValueOnce(delivery);
    pushDeliveryRepository.findOne.mockResolvedValueOnce(delivery);

    await service.sendPushDelivery(delivery);

    expect(delivery.status).toBe('pending');
    expect(delivery.availableAt).toBeInstanceOf(Date);

    delivery.attemptCount = 3;
    delivery.status = 'processing';
    webPushAdapter.send.mockRejectedValueOnce(new Error('temporary'));
    pushDeliveryRepository.save.mockResolvedValueOnce(delivery);
    pushDeliveryRepository.findOne.mockResolvedValueOnce(delivery);

    await service.sendPushDelivery(delivery);

    expect(delivery.status).toBe('failed');
  });

  it('claims pending and stale processing push deliveries for processing', async () => {
    const pendingDelivery = new NotificationPushDeliveryEntity();
    pendingDelivery.id = '00000000-0000-4000-8000-000000000501';
    pendingDelivery.status = 'pending';
    pendingDelivery.attemptCount = 0;
    pendingDelivery.notification = new NotificationEntity();
    pendingDelivery.notification.userId = userId;
    pendingDelivery.subscription = buildSubscription('subscription-1');

    const staleProcessingDelivery = new NotificationPushDeliveryEntity();
    staleProcessingDelivery.id = '00000000-0000-4000-8000-000000000502';
    staleProcessingDelivery.status = 'processing';
    staleProcessingDelivery.attemptCount = 1;
    staleProcessingDelivery.notification = new NotificationEntity();
    staleProcessingDelivery.notification.userId = userId;
    staleProcessingDelivery.subscription = buildSubscription('subscription-2');
    staleProcessingDelivery.processingStartedAt = new Date(
      '2026-01-01T00:00:00.000Z',
    );

    const queryBuilder = {
      innerJoin: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      andWhere: jest.fn().mockReturnThis(),
      orderBy: jest.fn().mockReturnThis(),
      setLock: jest.fn().mockReturnThis(),
      setOnLocked: jest.fn().mockReturnThis(),
      take: jest.fn().mockReturnThis(),
      getMany: jest
        .fn()
        .mockResolvedValue([pendingDelivery, staleProcessingDelivery]),
    };
    const deliveryRepo = {
      createQueryBuilder: jest.fn().mockReturnValue(queryBuilder),
      save: jest
        .fn()
        .mockImplementation(
          (deliveries: NotificationPushDeliveryEntity[]) => deliveries,
        ),
      find: jest
        .fn()
        .mockResolvedValue([pendingDelivery, staleProcessingDelivery]),
      update: jest.fn(),
    };
    pushDeliveryRepository.manager.transaction.mockImplementationOnce(
      async (
        callback: (manager: {
          query: jest.Mock;
          getRepository: (entity: unknown) => unknown;
        }) => unknown,
      ) =>
        callback({
          query: jest.fn().mockResolvedValue([[], 0]),
          getRepository: () => deliveryRepo,
        }),
    );

    const result = await service.claimPendingPushDeliveries(25);

    expect(queryBuilder.innerJoin).toHaveBeenCalledWith(
      'delivery.subscription',
      'subscription',
    );
    expect(queryBuilder.innerJoin).toHaveBeenCalledWith(
      'delivery.notification',
      'notification',
    );
    expect(queryBuilder.where).toHaveBeenCalledWith(expect.any(Object));
    expect(queryBuilder.andWhere).toHaveBeenCalledWith(
      'subscription.revokedAt IS NULL',
    );
    expect(queryBuilder.andWhere).toHaveBeenCalledWith(
      'notification.userId = subscription.userId',
    );
    expect(queryBuilder.setLock).toHaveBeenCalledWith(
      'pessimistic_write',
      undefined,
      ['delivery', 'subscription'],
    );
    expect(queryBuilder.setOnLocked).toHaveBeenCalledWith('skip_locked');
    expect(deliveryRepo.save).toHaveBeenCalledWith([
      expect.objectContaining({
        id: pendingDelivery.id,
        status: 'processing',
        attemptCount: 1,
      }),
      expect.objectContaining({
        id: staleProcessingDelivery.id,
        status: 'processing',
        attemptCount: 2,
      }),
    ]);
    expect(deliveryRepo.find).toHaveBeenCalledWith({
      where: { id: expect.any(Object) },
      relations: {
        notification: true,
        subscription: true,
      },
    });
    expect(result).toHaveLength(2);
    expect(result.map((delivery) => delivery.status)).toEqual([
      'processing',
      'processing',
    ]);
    expect(result.map((delivery) => delivery.attemptCount)).toEqual([1, 2]);
  });

  it('rechecks ownership under the subscription lock before sending', async () => {
    const delivery = new NotificationPushDeliveryEntity();
    delivery.id = 'mismatched-delivery';
    delivery.status = 'processing';
    pushDeliveryRepository.manager.transaction.mockImplementationOnce(
      async (callback) =>
        callback({
          query: jest
            .fn()
            .mockResolvedValue([{ id: delivery.id, ownersMatch: false }]),
          getRepository: (entity: unknown) =>
            entity === PushSubscriptionEntity
              ? pushSubscriptionRepository
              : pushDeliveryRepository,
        }),
    );

    await service.sendPushDelivery(delivery);

    expect(webPushAdapter.send).not.toHaveBeenCalled();
    expect(pushDeliveryRepository.update).toHaveBeenCalledWith(
      { id: delivery.id, status: 'processing' },
      expect.objectContaining({
        status: 'failed',
        lastError: 'Push delivery owner mismatch',
      }),
    );
  });

  it('does not save or reload push deliveries when no rows are claimed', async () => {
    const queryBuilder = {
      innerJoin: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      andWhere: jest.fn().mockReturnThis(),
      orderBy: jest.fn().mockReturnThis(),
      setLock: jest.fn().mockReturnThis(),
      setOnLocked: jest.fn().mockReturnThis(),
      take: jest.fn().mockReturnThis(),
      getMany: jest.fn().mockResolvedValue([]),
    };
    const deliveryRepo = {
      createQueryBuilder: jest.fn().mockReturnValue(queryBuilder),
      save: jest.fn(),
      find: jest.fn(),
      update: jest.fn(),
    };
    pushDeliveryRepository.manager.transaction.mockImplementationOnce(
      async (
        callback: (manager: {
          query: jest.Mock;
          getRepository: (entity: unknown) => unknown;
        }) => unknown,
      ) =>
        callback({
          query: jest.fn().mockResolvedValue([[], 0]),
          getRepository: () => deliveryRepo,
        }),
    );

    await expect(service.claimPendingPushDeliveries(25)).resolves.toEqual([]);

    expect(queryBuilder.setLock).toHaveBeenCalledWith(
      'pessimistic_write',
      undefined,
      ['delivery', 'subscription'],
    );
    expect(deliveryRepo.save).not.toHaveBeenCalled();
    expect(deliveryRepo.find).not.toHaveBeenCalled();
  });

  it('fails a delivery whose owner changed between selection and reload', async () => {
    const delivery = new NotificationPushDeliveryEntity();
    delivery.id = 'owner-changed-delivery';
    delivery.status = 'pending';
    delivery.attemptCount = 0;
    delivery.notification = new NotificationEntity();
    delivery.notification.userId = 'old-user';
    delivery.subscription = buildSubscription('changed-subscription');
    delivery.subscription.userId = 'new-user';
    const queryBuilder = {
      innerJoin: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      andWhere: jest.fn().mockReturnThis(),
      orderBy: jest.fn().mockReturnThis(),
      setLock: jest.fn().mockReturnThis(),
      setOnLocked: jest.fn().mockReturnThis(),
      take: jest.fn().mockReturnThis(),
      getMany: jest.fn().mockResolvedValue([delivery]),
    };
    const deliveryRepo = {
      createQueryBuilder: jest.fn().mockReturnValue(queryBuilder),
      save: jest.fn().mockResolvedValue([delivery]),
      find: jest.fn().mockResolvedValue([delivery]),
      update: jest.fn().mockResolvedValue({ affected: 1 }),
    };
    pushDeliveryRepository.manager.transaction.mockImplementationOnce(
      async (callback) =>
        callback({
          query: jest.fn().mockResolvedValue([[], 0]),
          getRepository: () => deliveryRepo,
        }),
    );

    await expect(service.claimPendingPushDeliveries(25)).resolves.toEqual([]);
    expect(deliveryRepo.update).toHaveBeenCalledWith(
      { id: expect.objectContaining({ _type: 'in' }), status: 'processing' },
      expect.objectContaining({
        status: 'failed',
        lastError: 'Push delivery is no longer owner-eligible',
      }),
    );
  });

  it('sweeps revoked or owner-mismatched abandoned work before claiming', async () => {
    const abandonedQuery = jest
      .fn()
      .mockResolvedValueOnce([[{ id: 'abandoned-delivery' }], 1]);
    const queryBuilder = {
      innerJoin: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      andWhere: jest.fn().mockReturnThis(),
      orderBy: jest.fn().mockReturnThis(),
      setLock: jest.fn().mockReturnThis(),
      setOnLocked: jest.fn().mockReturnThis(),
      take: jest.fn().mockReturnThis(),
      getMany: jest.fn().mockResolvedValue([]),
    };
    const deliveryRepo = {
      createQueryBuilder: jest.fn().mockReturnValue(queryBuilder),
      save: jest.fn(),
      find: jest.fn(),
      update: jest.fn(),
    };
    pushDeliveryRepository.manager.transaction.mockImplementationOnce(
      async (callback) =>
        callback({
          query: abandonedQuery,
          getRepository: () => deliveryRepo,
        }),
    );

    await expect(service.claimPendingPushDeliveries(25)).resolves.toEqual([]);

    expect(abandonedQuery).toHaveBeenCalledWith(
      expect.stringContaining('subscription."revokedAt" IS NOT NULL'),
      [expect.any(Date), 500],
    );
    expect(abandonedQuery.mock.calls[0][0]).toContain(
      'delivery."processingStartedAt" IS NULL',
    );
    expect(abandonedQuery.mock.calls[0][0]).toContain(
      'notification."userId" <> subscription."userId"',
    );
    expect(abandonedQuery.mock.calls[0][0]).toContain('"updatedAt" = now()');
  });

  it('fails closed when PostgreSQL returns a malformed sweep result', async () => {
    const deliveryRepo = {
      createQueryBuilder: jest.fn(),
    };
    pushDeliveryRepository.manager.transaction.mockImplementationOnce(
      async (callback) =>
        callback({
          query: jest.fn().mockResolvedValue([{ id: 'not-a-driver-tuple' }]),
          getRepository: () => deliveryRepo,
        }),
    );

    await expect(service.claimPendingPushDeliveries(25)).rejects.toThrow(
      'Unexpected PostgreSQL mutation result',
    );
    expect(deliveryRepo.createQueryBuilder).not.toHaveBeenCalled();
  });

  it('retains pending work while cleaning terminal deliveries and old notification records', async () => {
    const notificationCandidates = {
      select: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      andWhere: jest.fn().mockReturnThis(),
      orderBy: jest.fn().mockReturnThis(),
      addOrderBy: jest.fn().mockReturnThis(),
      take: jest.fn().mockReturnThis(),
      setLock: jest.fn().mockReturnThis(),
      setOnLocked: jest.fn().mockReturnThis(),
      getMany: jest
        .fn()
        .mockResolvedValue([
          { id: 'notification-1' },
          { id: 'notification-2' },
        ]),
    };
    const deliveryCandidates = {
      select: jest.fn().mockReturnThis(),
      where: jest.fn().mockReturnThis(),
      andWhere: jest.fn().mockReturnThis(),
      orderBy: jest.fn().mockReturnThis(),
      addOrderBy: jest.fn().mockReturnThis(),
      take: jest.fn().mockReturnThis(),
      setLock: jest.fn().mockReturnThis(),
      setOnLocked: jest.fn().mockReturnThis(),
      getMany: jest
        .fn()
        .mockResolvedValue([{ id: 'delivery-1' }, { id: 'delivery-2' }]),
    };
    const scopedNotificationRepository = {
      createQueryBuilder: jest.fn().mockReturnValue(notificationCandidates),
      delete: jest.fn().mockResolvedValue({ affected: 2 }),
    };
    const scopedDeliveryRepository = {
      createQueryBuilder: jest.fn().mockReturnValue(deliveryCandidates),
      delete: jest.fn().mockResolvedValue({ affected: 2 }),
    };
    notificationRepository.manager.transaction.mockImplementationOnce(
      async (callback: (manager: { getRepository: jest.Mock }) => unknown) =>
        callback({
          getRepository: jest.fn((entity: unknown) =>
            entity === NotificationEntity
              ? scopedNotificationRepository
              : scopedDeliveryRepository,
          ),
        }),
    );

    await expect(
      service.cleanupOldNotificationRecords(
        new Date('2026-02-01T00:00:00.000Z'),
      ),
    ).resolves.toEqual({ deliveries: 2, notifications: 2 });

    expect(deliveryCandidates.take).toHaveBeenCalledWith(500);
    expect(deliveryCandidates.setLock).toHaveBeenCalledWith(
      'pessimistic_write',
    );
    expect(deliveryCandidates.setOnLocked).toHaveBeenCalledWith('skip_locked');
    expect(scopedDeliveryRepository.delete).toHaveBeenCalledWith({
      id: expect.objectContaining({ _type: 'in' }),
      status: expect.objectContaining({ _type: 'in' }),
    });
    expect(notificationCandidates.andWhere).toHaveBeenCalledWith(
      expect.stringContaining('"delivery"."notificationId"'),
    );
    expect(notificationCandidates.take).toHaveBeenCalledWith(500);
    expect(notificationCandidates.setLock).toHaveBeenCalledWith(
      'pessimistic_write',
    );
    expect(notificationCandidates.setOnLocked).toHaveBeenCalledWith(
      'skip_locked',
    );
  });
});
