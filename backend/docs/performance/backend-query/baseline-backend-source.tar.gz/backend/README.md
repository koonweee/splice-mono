# Splice - NestJS Application

A NestJS application for managing financial accounts and transactions.

## Quick Start

Get up and running in 3 steps:

```bash
# 1. Clone and navigate to the project
git clone <repository-url>
cd splice-rewrite

# 2. Copy environment variables (already configured with defaults)
cp .env.example .env

# 3. Start the development environment
docker-compose up
```

That's it! Your application will be running at `http://localhost:3000` 🚀

## Prerequisites

- [Docker](https://www.docker.com/get-started) installed on your machine
- [Docker Compose](https://docs.docker.com/compose/install/) installed
- (Optional) [Node.js 24+](https://nodejs.org/) and [Yarn](https://yarnpkg.com/) for local development

## Development Setup

### Using Docker (Recommended)

1. **Clone the repository**

   ```bash
   git clone <repository-url>
   cd splice-rewrite
   ```

2. **Set up environment variables**

   Copy the example environment file and adjust values if needed:

   ```bash
   cp .env.example .env
   ```

3. **Start the development environment**

   This will start both PostgreSQL and the NestJS application:

   ```bash
   docker-compose up
   ```

   Or run in detached mode:

   ```bash
   docker-compose up -d
   ```

4. **Access the application**
   - Application: `http://localhost:3000`
   - API Documentation (Swagger): `http://localhost:3000/api`

### Development Commands

```bash
# Start all services
docker-compose up

# Start in detached mode
docker-compose up -d

# Stop all services
docker-compose down

# Stop and remove volumes (WARNING: This will delete database data)
docker-compose down -v

# View logs
docker-compose logs -f

# View logs for specific service
docker-compose logs -f app
docker-compose logs -f postgres

# Rebuild containers (after dependency changes)
docker-compose up --build

# Execute commands in the app container
docker-compose exec app yarn test
docker-compose exec app yarn lint

# Access PostgreSQL database
docker-compose exec postgres psql -U splice_user -d splice_dev
```

### Hot Module Replacement (HMR)

The development environment is configured with automatic reload. Any changes you make to the source code in the `./src` directory will automatically trigger a rebuild and restart of the application.

## Local Development (Without Docker)

If you prefer to run the application locally without Docker:

1. **Install dependencies**

   ```bash
   yarn install
   ```

2. **Set up PostgreSQL**

   Make sure PostgreSQL is running locally and update the `.env` file with your local database credentials.

3. **Start the development server**
   ```bash
   yarn start:dev
   ```

> When updating or installing new dependencies, do `yarn docker:down` then `yarn docker:up:build`

## MCP

The standalone MCP resource is `https://splice-mcp.kw0.dev/mcp`. It uses Auth0
OAuth with `splice:read` and `splice:write`; it does not accept Splice personal
access tokens and is not mounted on the Nest API origin. The listener is
disabled by default for ordinary local API development.

The surface contains 25 tools, typed structured/text results, data resources,
workflow prompts, two progressive-enhancement MCP Apps, SDK v2 projection
input/resume, and preview-token-protected categorization writes. See the
[canonical MCP runbook](../docs/mcp.md) for the complete contract, local tests,
fixture validation, production rollout, smoke tests, and rollback.

Cash Flow and Portfolio are selectively invoked mobile-first visual answers,
not general dashboards. Cash Flow uses `visualize_cash_flow` linked to
`ui://splice/cash-flow/v3.html`. Portfolio uses `visualize_portfolio` linked to
`ui://splice/portfolio/v3.html`; it shows latest ownership and concentration in
one server-normalized USD view, with top-five plus `Other` evidence and compact
inline position detail. Selection publishes minimal passive model context. On
hosts that advertise text `ui/message`, selected detail also offers one
deliberate **Ask about this holding** action; it is hidden when unsupported and
never sends automatically.

For MCP App UI work, run `yarn mcp-apps:dev` for the live official-host loop.
Use `yarn mcp-apps:visual --app cash-flow` for the overview, income,
comparison, and category-focus matrix, or `yarn mcp-apps:visual --app portfolio`
for concentrated, nearly-even, two-position, and long-label portfolios. The
ranked composition was selected through a one-time official-host comparison
against a compact donut; no chart mode or selector ships. The visual loop
captures desktop dark, iPhone dark/light, a 320 px boundary,
loading-to-ready videos, browser evidence, and contact sheets. Add
`--scenario empty`, `--scenario helper-error`, or
`--scenario primary-error` for truthful alternate states; use `--case` to
isolate one presentation. The first run prepares the exact pinned official host
automatically; `yarn mcp-apps:setup` may also be run explicitly. Run
`yarn test:mcp-apps` for the focused browser-runtime, App contract, and real
loopback MCP listener suite. Record three explicit refinement passes and final
ChatGPT Web/mobile smoke as described in the
[canonical runbook](../docs/mcp.md#local-mcp-app-standard-host-validation).

## API Documentation

Swagger/OpenAPI documentation is available at `/api` when the server is running.

### Viewing the API

1. Start the server: `docker-compose up` or `yarn start:dev`
2. Open `http://localhost:3000/api` in your browser
3. The OpenAPI JSON spec is available at `http://localhost:3000/api-json`

### Generating a Typesafe Client

You can generate a fully typed API client from the OpenAPI spec using tools like:

**Using `@hey-api/openapi-ts`:**

```bash
# Install the generator
yarn add -D @hey-api/openapi-ts

# Generate the client (server must be running)
npx @hey-api/openapi-ts -i http://localhost:3000/api-json -o ./src/client
```

**Using `openapi-typescript` (types only):**

```bash
yarn add -D openapi-typescript

# Generate TypeScript types
npx openapi-typescript http://localhost:3000/api-json -o ./src/api-types.ts
```

**Using `orval` (React Query/SWR hooks):**

```bash
yarn add -D orval

# Generate with React Query hooks
npx orval --input http://localhost:3000/api-json --output ./src/api
```

## Database Migrations

This project uses TypeORM migrations to manage database schema changes. Migrations are used in all environments (development and production).

### Migration Commands

```bash
# Generate a new migration from entity changes
yarn migration:generate src/migrations/MigrationName

# Run pending migrations (local, requires DB connection)
yarn migration:run

# Run migrations in Docker dev environment
yarn docker:migration:run

# Revert the last migration
yarn migration:revert

# Show migration status
yarn migration:show
```

### Workflow for Schema Changes

1. **Make changes to your entity files** (e.g., add a column in `account.entity.ts`)

2. **Generate a migration:**

   ```bash
   yarn migration:generate src/migrations/AddFieldToAccount
   ```

   TypeORM compares your entities to the current DB and generates the SQL diff.

3. **Review the generated migration** in `src/migrations/`. Verify the `up()` and `down()` methods are correct.

4. **Apply the migration:**

   ```bash
   # If running locally
   yarn migration:run

   # If using Docker
   yarn docker:migration:run
   ```

5. **Commit the migration file** along with your entity changes.

### How Migrations Work

- TypeORM tracks executed migrations in a `migrations` table in your database
- Running `migration:run` only executes migrations that haven't been run yet
- In production, run migrations explicitly before rolling out app replicas:

```bash
yarn migration:run:prod
```

## Production deployment notes

- The backend container starts the API only; it does not run schema migrations on boot.
- Use split origins in production:
  - `FRONTEND_DOMAIN=https://splice.<base-domain>`
  - `API_DOMAIN=https://splice-api.<base-domain>`
- Run migrations once as a separate deploy task before restarting or scaling API containers.
- Required production variables:
  - `POSTGRES_HOST`
  - `POSTGRES_PORT`
  - `POSTGRES_DB`
  - `POSTGRES_USER`
  - `POSTGRES_PASSWORD`
  - `JWT_SECRET`
  - `FRONTEND_DOMAIN`
  - `API_DOMAIN`
- Common optional variables:
  - `PLAID_CLIENT_ID`
  - `PLAID_SECRET`
  - `ALCHEMY_API_KEY`
  - `SEQ_SERVER_URL`
  - `SEQ_API_KEY`

### Adding a New Entity

When adding a new entity:

1. Create your `*.entity.ts` file (entities are auto-loaded)
2. Generate a migration to create the table: `yarn migration:generate src/migrations/CreateMyEntity`

## Testing

```bash
# Run unit tests
yarn test

# Run tests in watch mode
yarn test:watch

# Run tests with coverage
yarn test:cov

# Run e2e tests
yarn test:e2e
```

## Environment Variables

Key environment variables (see `.env.example` for all variables):

- `PORT` - Application port (default: 3000)
- `NODE_ENV` - Environment mode (development/production)
- `API_DOMAIN` - API domain for webhooks (e.g., `https://api.example.com`)
- `FRONTEND_DOMAIN` - Frontend domain for CORS (e.g., `https://app.example.com`)
- `POSTGRES_HOST` - PostgreSQL host
- `POSTGRES_PORT` - PostgreSQL port (default: 5432)
- `POSTGRES_DB` - Database name
- `POSTGRES_USER` - Database user
- `POSTGRES_PASSWORD` - Database password

Any environment variables added to .env should also be added to the docker-compose

## Project Structure

```
├── src/                  # Application source code
│   ├── account/         # Account module
│   ├── types/           # TypeScript type definitions
│   ├── dtos/            # Data transfer objects
│   ├── zod-validation/  # Custom validation pipes
│   └── main.ts          # Application entry point
├── test/                # Test files
│   ├── account/         # Account tests
│   └── mocks/           # Test mocks
├── bruno/               # API testing collection
├── docker-compose.yml   # Docker compose configuration
├── Dockerfile.dev       # Development Docker configuration
└── .env                 # Environment variables (not in git)
```

## License

UNLICENSED
