import { AccountSubtype, AccountType } from 'plaid';
import { z } from 'zod';
import { registerSchema } from '../common/zod-api-response';
import { CryptoAccountType } from './AccountType';
import { MoneyWithSignSchema } from './MoneyWithSign';
import { OwnedSchema } from './Timestamps';
import { CreateTransactionDtoSchema } from './Transaction';

/**
 * Supported crypto networks for wallet linking
 */
export const CryptoNetworkSchema = z.enum(['ethereum', 'bitcoin']);
export type CryptoNetwork = z.infer<typeof CryptoNetworkSchema>;

/**
 * Request to initiate bank account linking
 */
export const InitiateLinkRequestSchema = registerSchema(
  'InitiateLinkRequest',
  z.object({
    redirectUri: z.string().optional(), // Optional redirect after linking (Plaid)
    /** Existing bank link ID for update/reauth flows */
    bankLinkId: z.string().uuid().optional(),
    /** Existing manual account ID to convert into a linked account */
    convertAccountId: z.string().uuid().optional(),
    /** Wallet address for crypto linking */
    walletAddress: z.string().optional(),
    /** Crypto network for wallet linking */
    network: CryptoNetworkSchema.optional(),
  }),
);

export type InitiateLinkRequest = z.infer<typeof InitiateLinkRequestSchema>;

/**
 * Base schema for link responses (shared fields)
 */
const BaseLinkResponseSchema = z.object({
  /** URL for user to add their banks (ie. Plaid's Link flow) */
  linkUrl: z.string().optional(),
  /** When the link expires */
  expiresAt: z.date().optional(),
});

/**
 * Response from initiating bank account linking (public API)
 */
export const InitiateLinkResponseSchema = registerSchema(
  'InitiateLinkResponse',
  BaseLinkResponseSchema,
);

export type InitiateLinkResponse = z.infer<typeof InitiateLinkResponseSchema>;

/**
 * Extended account type schema that accepts both Plaid and crypto types
 */
const ExtendedAccountTypeSchema = z.union([
  z.nativeEnum(AccountType),
  z.nativeEnum(CryptoAccountType),
]);

export const APIAccountSchema = z.object({
  /** ID of account on external API */
  accountId: z.string(),
  /** Name of account */
  name: z.string(),
  /** Mask of account number */
  mask: z.string().nullable(),
  /** Type of account (Plaid AccountType or CryptoAccountType) */
  type: ExtendedAccountTypeSchema,
  /** Subtype of account */
  subType: z.nativeEnum(AccountSubtype).nullable(),
  /** Available balance */
  availableBalance: MoneyWithSignSchema,
  /** Current balance */
  currentBalance: MoneyWithSignSchema,
});

export type APIAccount = z.infer<typeof APIAccountSchema>;

/**
 * Institution info from the bank provider
 */
export const InstitutionSchema = z.object({
  /** External institution ID from provider (e.g., Plaid institution_id) */
  id: z.string().nullable().optional(),
  /** Institution name (e.g., "Chase", "Bank of America") */
  name: z.string().nullable().optional(),
});

export type Institution = z.infer<typeof InstitutionSchema>;

/**
 * Status of a bank link connection
 */
export const BankLinkStatusEnum = z.enum(['OK', 'ERROR', 'PENDING_REAUTH']);
export type BankLinkStatus = z.infer<typeof BankLinkStatusEnum>;

/**
 * Bank Link - represents a connection to an external bank provider
 */
export const BankLinkSchema = z
  .object({
    /** Unique identifier */
    id: z.string().uuid(),
    /** Provider name (e.g., 'plaid', 'simplefin') */
    providerName: z.string(),
    /** Provider-specific authentication data */
    authentication: z.record(z.string(), z.any()),
    /** Array of linked account IDs */
    accountIds: z.array(z.string()),
    /** Institution ID from provider */
    institutionId: z.string().nullable().optional(),
    /** Institution name */
    institutionName: z.string().nullable().optional(),
    /** Current status of the bank link */
    status: BankLinkStatusEnum,
    /** When the status was last updated */
    statusDate: z.coerce.date(),
    /** Additional status information (e.g., error details) */
    statusBody: z.record(z.string(), z.any()).nullable().optional(),
  })
  .merge(OwnedSchema);

export type BankLink = z.infer<typeof BankLinkSchema>;

/**
 * Sanitized BankLink schema - excludes sensitive authentication data
 * Use this for API responses and when embedding in other types
 */
export const SanitizedBankLinkSchema = registerSchema(
  'SanitizedBankLink',
  BankLinkSchema.omit({ authentication: true }),
);

export type SanitizedBankLink = z.infer<typeof SanitizedBankLinkSchema>;

/**
 * DTO for creating a new BankLink (excludes id, userId, status fields, and timestamps which are auto-generated)
 */
export const CreateBankLinkDtoSchema = BankLinkSchema.omit({
  id: true,
  userId: true,
  status: true,
  statusDate: true,
  createdAt: true,
  updatedAt: true,
});

export type CreateBankLinkDto = z.infer<typeof CreateBankLinkDtoSchema>;

/**
 * DTO for updating an existing BankLink
 */
export const UpdateBankLinkDtoSchema = CreateBankLinkDtoSchema.partial();

export type UpdateBankLinkDto = z.infer<typeof UpdateBankLinkDtoSchema>;

/**
 * Response after processing webhook/linking accounts
 *
 * Account name, identifier and authentication data
 */
export const LinkCompletionResponseSchema = z.object({
  /** Account authentication data */
  authentication: z.record(z.string(), z.any()),
  accounts: z.array(APIAccountSchema),
  /** Institution info from the provider */
  institution: InstitutionSchema.optional(),
});

export type LinkCompletionResponse = z.infer<
  typeof LinkCompletionResponseSchema
>;

/**
 * Response from initiating a link flow (internal provider response)
 * Extends BaseLinkResponseSchema with additional internal fields
 */
export const LinkInitiationResponseSchema = BaseLinkResponseSchema.extend({
  /**
   * Unique ID for matching webhooks
   * This is set to link token to match the initial create request to the webhook response
   * Optional for providers that don't use webhooks (e.g., crypto)
   */
  webhookId: z.string().optional(),
  /** Provider-specific data */
  metadata: z.record(z.string(), z.any()).optional(),
  /**
   * Updated provider-specific user details to persist
   * If returned, these will replace the user's existing provider details for this provider
   */
  updatedProviderUserDetails: z.record(z.string(), z.unknown()).optional(),
  /**
   * For providers without async webhook flow (e.g., crypto), accounts can be
   * returned immediately for synchronous creation
   */
  immediateAccounts: z.array(LinkCompletionResponseSchema).optional(),
});

export type LinkInitiationResponse = z.infer<
  typeof LinkInitiationResponseSchema
>;

/**
 * Response from getAccounts - includes accounts and institution metadata
 */
export const GetAccountsResponseSchema = z.object({
  accounts: z.array(APIAccountSchema),
  /** Institution info from the provider */
  institution: InstitutionSchema.optional(),
});

export type GetAccountsResponse = z.infer<typeof GetAccountsResponseSchema>;

/**
 * Response from a transaction sync operation (e.g., Plaid /transactions/sync)
 * Contains added, modified, and removed transactions along with cursor state
 */
export const TransactionSyncResponseSchema = z.object({
  /** New transactions to add */
  added: z.array(CreateTransactionDtoSchema),
  /** Existing transactions that have been modified */
  modified: z.array(CreateTransactionDtoSchema),
  /** External transaction IDs of removed transactions */
  removed: z.array(z.string()),
  /** Cursor for the next sync call */
  nextCursor: z.string(),
  /** Whether there are more pages to fetch */
  hasMore: z.boolean(),
});

export type TransactionSyncResponse = z.infer<
  typeof TransactionSyncResponseSchema
>;
